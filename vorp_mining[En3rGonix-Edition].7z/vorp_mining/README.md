# vorp_mining
Mining script 
![Screenshot_10](https://user-images.githubusercontent.com/101003021/190602935-bec09f9a-4651-44b0-b2b9-3688f0a51df2.png)

## 1. Requirements

- [VORP-Core GitHub](https://github.com/VORPCORE/vorp-core-lua)
- [VORP-Core Discord](https://discord.com/invite/xhJRGhQFRr)
- **NEED** [syn_minigame](https://cdn.discordapp.com/attachments/903875147050655744/906890251312721940/syn_minigame.rar)

## 2. insallation

- `ensure vorp_mining` in your resources.cfg
- `ensure syn_minigame` in your resources.cfg

## 3. features
- Mine rocks and get items 
- this script uses the tooll with durability "metadata"
- Forbid Mining rocks in cities if you want
- Random messages when minigame fail

## 4. credits
- The creator of the original script and everyone who contributed to it.
- systemNEO and DerHobbs for revision
